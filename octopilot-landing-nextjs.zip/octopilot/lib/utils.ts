import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function staggerDelay(index: number, base = 0.1): string {
  return `${index * base}s`;
}

export const SITE = {
  name:          "Octopilot",
  tagline:       "Sales Proof Intelligence",
  description:   "AI-powered Sales Proof Intelligence. Generate visual ranking proof yang tidak bisa dibantah — dalam hitungan detik, tanpa izin akses dari siapapun.",
  url:           "https://octopilot.co",
  twitterHandle: "@octopilot",
  og: { image: "/og-image.png", width: 1200, height: 630 },
} as const;
