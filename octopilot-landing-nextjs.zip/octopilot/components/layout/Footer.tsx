import Link from "next/link";
import { Zap } from "lucide-react";
import { Divider } from "@/components/ui/divider";

const FOOTER_LINKS = {
  Product: [
    { label: "How it works", href: "#solution"     },
    { label: "Features",     href: "#features"     },
    { label: "Use Cases",    href: "#usecases"     },
    { label: "Pricing",      href: "#pricing"      },
    { label: "Early Access", href: "#early-access" },
  ],
  Company: [
    { label: "About",     href: "/about"     },
    { label: "Blog",      href: "/blog"      },
    { label: "Changelog", href: "/changelog" },
    { label: "Careers",   href: "/careers"   },
    { label: "Contact",   href: "mailto:hello@octopilot.co" },
  ],
  Legal: [
    { label: "Privacy Policy", href: "/privacy"  },
    { label: "Terms of Use",   href: "/terms"    },
    { label: "Security",       href: "/security" },
    { label: "DPA",            href: "/dpa"      },
  ],
};

export function Footer() {
  return (
    <footer className="border-t border-white/[0.06]">
      <div className="container mx-auto py-16">
        {/* Top grid */}
        <div className="grid grid-cols-1 gap-12 md:grid-cols-[1.8fr_1fr_1fr_1fr] mb-16">
          {/* Brand column */}
          <div>
            <Link
              href="/"
              className="flex items-center gap-2.5 font-bold text-[15px] tracking-tight text-ink mb-4"
              aria-label="Octopilot home"
            >
              <span
                aria-hidden
                className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand shadow-[0_4px_12px_rgba(255,99,8,0.35)]"
              >
                <Zap className="h-3.5 w-3.5 text-white" strokeWidth={2.5} />
              </span>
              Octopilot
            </Link>

            <p className="text-sm text-ink-faint leading-relaxed max-w-[200px]">
              The AI execution engine for founders, developers, and indie hackers.
            </p>

            <p className="mt-5 text-[11px] font-mono tracking-[0.08em] text-brand uppercase">
              Ship. Execute. Repeat.
            </p>

            {/* Social links */}
            <div className="flex gap-3 mt-5">
              {[
                { label: "Twitter/X",  href: "https://twitter.com/octopilotco",  icon: "𝕏" },
                { label: "GitHub",     href: "https://github.com/octopilotco",   icon: "⬡" },
                { label: "LinkedIn",   href: "https://linkedin.com/company/octopilot", icon: "in" },
              ].map(({ label, href, icon }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="h-8 w-8 flex items-center justify-center rounded-lg bg-white/[0.05] border border-edge text-ink-faint text-xs hover:text-ink hover:border-edge-mid hover:bg-white/[0.08] transition-colors"
                >
                  {icon}
                </a>
              ))}
            </div>
          </div>

          {/* Link columns */}
          {Object.entries(FOOTER_LINKS).map(([title, links]) => (
            <div key={title}>
              <h3 className="text-[11px] font-mono tracking-[0.14em] uppercase text-ink-faint mb-5">
                {title}
              </h3>
              <ul className="flex flex-col gap-2.5" role="list">
                {links.map(({ label, href }) => (
                  <li key={label}>
                    <Link
                      href={href}
                      className="text-[13.5px] text-ink-muted hover:text-ink transition-colors duration-150"
                    >
                      {label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <Divider />

        {/* Bottom bar */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-8">
          <p className="text-[12px] font-mono tracking-wide text-ink-faint">
            © {new Date().getFullYear()} Octopilot, Inc. All rights reserved.
          </p>
          <p className="text-[12px] font-mono tracking-wide text-ink-faint">
            Built with ⚡ for builders.
          </p>
        </div>
      </div>
    </footer>
  );
}
