"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Zap, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const NAV_LINKS = [
  { label: "Product",    href: "#solution" },
  { label: "Features",   href: "#features" },
  { label: "Use Cases",  href: "#usecases" },
  { label: "Pricing",    href: "#pricing" },
  { label: "FAQ",        href: "#faq" },
] as const;

export function Navbar() {
  const [scrolled,    setScrolled]    = useState(false);
  const [mobileOpen,  setMobileOpen]  = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close mobile menu on ESC
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMobileOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-[#080809]/90 backdrop-blur-xl border-b border-white/[0.06]"
          : "bg-transparent"
      )}
    >
      <nav
        className="container mx-auto flex h-16 items-center justify-between"
        aria-label="Main navigation"
      >
        {/* ── Logo ── */}
        <Link
          href="/"
          className="flex items-center gap-2.5 font-bold text-[15px] tracking-tight text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/50 rounded-md"
          aria-label="Octopilot home"
        >
          <span
            aria-hidden
            className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand shadow-[0_4px_12px_rgba(255,99,8,0.35)]"
          >
            <Zap className="h-3.5 w-3.5 text-white" strokeWidth={2.5} />
          </span>
          Octopilot
        </Link>

        {/* ── Desktop links ── */}
        <ul
          className="hidden md:flex items-center gap-0.5"
          role="list"
        >
          {NAV_LINKS.map(({ label, href }) => (
            <li key={href}>
              <Link
                href={href}
                className="block px-3.5 py-2 text-[13.5px] text-ink-muted hover:text-ink hover:bg-white/[0.04] rounded-lg transition-colors duration-150"
              >
                {label}
              </Link>
            </li>
          ))}
        </ul>

        {/* ── Desktop CTA ── */}
        <div className="hidden md:flex items-center gap-3">
          <Link
            href="/login"
            className="text-[13.5px] text-ink-muted hover:text-ink transition-colors duration-150"
          >
            Sign in
          </Link>
          <Button variant="primary" size="default" asChild>
            <Link href="#early-access">Get Early Access</Link>
          </Button>
        </div>

        {/* ── Mobile hamburger ── */}
        <button
          className="md:hidden p-1.5 text-ink-muted hover:text-ink transition-colors"
          onClick={() => setMobileOpen((v) => !v)}
          aria-label={mobileOpen ? "Close menu" : "Open menu"}
          aria-expanded={mobileOpen}
          aria-controls="mobile-menu"
        >
          {mobileOpen
            ? <X className="h-5 w-5" />
            : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      {/* ── Mobile drawer ── */}
      <div
        id="mobile-menu"
        role="dialog"
        aria-modal="true"
        aria-label="Mobile navigation"
        className={cn(
          "md:hidden overflow-hidden transition-all duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]",
          mobileOpen ? "max-h-[600px] opacity-100" : "max-h-0 opacity-0"
        )}
      >
        <div className="bg-[#0f1012] border-t border-white/[0.06] px-5 pb-6 pt-4">
          <ul className="flex flex-col gap-1 mb-5" role="list">
            {NAV_LINKS.map(({ label, href }) => (
              <li key={href}>
                <Link
                  href={href}
                  onClick={() => setMobileOpen(false)}
                  className="block px-3 py-2.5 text-sm text-ink-muted hover:text-ink hover:bg-white/[0.04] rounded-lg transition-colors"
                >
                  {label}
                </Link>
              </li>
            ))}
          </ul>
          <div className="flex flex-col gap-2">
            <Button variant="secondary" size="lg" className="w-full" asChild>
              <Link href="/login">Sign in</Link>
            </Button>
            <Button variant="primary" size="lg" className="w-full" asChild>
              <Link href="#early-access">Get Early Access</Link>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
