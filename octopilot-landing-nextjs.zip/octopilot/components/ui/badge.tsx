import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

interface BadgeProps {
  children: ReactNode;
  variant?: "brand" | "green" | "neutral" | "warn";
  className?: string;
}

export function Badge({
  children,
  variant = "neutral",
  className,
}: BadgeProps) {
  const styles = {
    brand:   "bg-brand-dim text-brand border border-brand-border",
    green:   "bg-ok/10 text-ok border border-ok/20",
    warn:    "bg-warn/10 text-warn border border-warn/20",
    neutral: "bg-white/[0.05] text-ink-muted border border-edge",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[12px] font-medium",
        styles[variant],
        className
      )}
    >
      {children}
    </span>
  );
}

export function PulseDot({ color = "brand" }: { color?: "brand" | "green" }) {
  return (
    <span
      aria-hidden
      className={cn(
        "h-1.5 w-1.5 rounded-full animate-pulse-dot",
        color === "brand" ? "bg-brand" : "bg-ok"
      )}
    />
  );
}
