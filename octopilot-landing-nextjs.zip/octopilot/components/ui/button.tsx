import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  // Base
  [
    "inline-flex items-center justify-center gap-2 whitespace-nowrap",
    "font-semibold tracking-[-0.01em] select-none",
    "transition-all duration-200 ease-[cubic-bezier(0.22,1,0.36,1)]",
    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/60",
    "disabled:pointer-events-none disabled:opacity-40",
    "active:scale-[0.97]",
  ].join(" "),
  {
    variants: {
      variant: {
        primary: [
          "bg-brand text-white",
          "shadow-[0_1px_0_rgba(255,255,255,0.12)_inset,0_4px_20px_rgba(255,99,8,0.28)]",
          "hover:bg-brand-hover hover:shadow-[0_1px_0_rgba(255,255,255,0.12)_inset,0_6px_28px_rgba(255,99,8,0.4)]",
          "hover:-translate-y-[1px]",
        ].join(" "),
        secondary: [
          "bg-white/[0.06] text-ink-muted border border-edge-mid",
          "hover:bg-white/[0.09] hover:text-ink hover:border-edge-bright",
          "hover:-translate-y-[1px]",
        ].join(" "),
        outline: [
          "bg-transparent text-ink-muted border border-edge-mid",
          "hover:border-edge-bright hover:text-ink hover:bg-white/[0.03]",
        ].join(" "),
        ghost: [
          "bg-transparent text-ink-muted",
          "hover:bg-white/[0.05] hover:text-ink",
        ].join(" "),
        link: [
          "bg-transparent text-brand underline-offset-4 hover:underline p-0 h-auto",
          "focus-visible:ring-0",
        ].join(" "),
      },
      size: {
        sm:      "h-8  px-4   text-xs  rounded-md",
        default: "h-10 px-5   text-sm  rounded-lg",
        lg:      "h-12 px-8   text-sm  rounded-xl",
        xl:      "h-14 px-10  text-[15px] rounded-xl",
        icon:    "h-9  w-9             rounded-lg",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "default",
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        ref={ref}
        className={cn(buttonVariants({ variant, size }), className)}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };
