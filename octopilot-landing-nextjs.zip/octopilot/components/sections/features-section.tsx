/**
 * FeaturesSection — 6 Feature Cards
 * PURPOSE: Concrete capability proof. Shows range without bloat.
 * ─────────────────────────────────────────────────────────────
 */

import { BarChart3, Zap, Share2, Globe, Shield, TrendingDown } from "lucide-react";
import { cn } from "@/lib/utils";

const features = [
  {
    Icon:  BarChart3,
    title: "Live Ranking Visualizer",
    body:  "Ranking data real-time dari ratusan sumber. Chart interaktif. Tidak ada delay, tidak ada manual refresh.",
    tag:   "Core",
  },
  {
    Icon:  TrendingDown,
    title: "AI Overview Impact Map",
    body:  "Deteksi AI Overview yang menghancurkan visibility organik prospek — sebelum mereka tahu masalah ini ada.",
    tag:   "New",
  },
  {
    Icon:  Zap,
    title: "47-Second Proof Engine",
    body:  "Input domain → Output proof. Rata-rata 47 detik. Cukup cepat untuk di-generate live saat meeting berlangsung.",
    tag:   "Speed",
  },
  {
    Icon:  Share2,
    title: "Zero-Friction Sharing",
    body:  "Shareable link, PDF export, atau embed di proposal. Prospek bisa buka di browser tanpa install apapun.",
    tag:   "Delivery",
  },
  {
    Icon:  Globe,
    title: "Multi-Region Support",
    body:  "Track ranking di 90+ negara. Ideal untuk agensi yang pitching klien dengan target pasar internasional.",
    tag:   "Coverage",
  },
  {
    Icon:  Shield,
    title: "No Permission Required",
    body:  "Tidak perlu GSC. Tidak perlu GA4. Tidak perlu email ke klien prospek. Data publik, diambil secara legal dan real-time.",
    tag:   "Privacy",
  },
];

interface FeaturesSectionProps {
  className?: string;
}

export function FeaturesSection({ className }: FeaturesSectionProps) {
  return (
    <section
      id="features"
      aria-labelledby="features-heading"
      className={cn("section-features", className)}
      style={{
        padding:      "120px 40px",
        borderBottom: "1px solid var(--border)",
        position:     "relative",
        overflow:     "hidden",
      }}
    >
      <div
        aria-hidden="true"
        style={{
          position:   "absolute",
          inset:      0,
          pointerEvents: "none",
          background: "radial-gradient(ellipse 50% 50% at 10% 50%, rgba(255,99,8,0.04) 0%, transparent 70%)",
        }}
      />

      <div style={{ maxWidth: "var(--content-width)", margin: "0 auto", position: "relative", zIndex: 1 }}>
        {/* Header */}
        <div style={{ marginBottom: "72px" }}>
          <span className="section-label" style={{ display: "block", marginBottom: "20px" }}>Features</span>
          <h2
            id="features-heading"
            style={{
              fontFamily:  "var(--font-serif)",
              fontSize:    "clamp(32px, 4.5vw, 58px)",
              lineHeight:  0.97,
              fontWeight:  400,
              color:       "var(--text)",
              maxWidth:    "520px",
            }}
          >
            Semua yang kamu butuhkan untuk{" "}
            <em style={{ fontStyle: "italic", color: "rgba(240,240,238,0.38)" }}>
              close tanpa friction.
            </em>
          </h2>
        </div>

        {/* Feature grid */}
        <div
          role="list"
          aria-label="Octopilot features"
          style={{
            display:               "grid",
            gridTemplateColumns:   "repeat(auto-fit, minmax(300px, 1fr))",
            gap:                   "1px",
            border:                "1px solid var(--border)",
            borderRadius:          "var(--radii-outer)",
            overflow:              "hidden",
          }}
        >
          {features.map(({ Icon, title, body, tag }, i) => (
            <article
              key={title}
              role="listitem"
              style={{
                padding:    "40px 36px",
                background: "var(--bg-card)",
                borderRight: (i % 3 !== 2) ? "1px solid var(--border)" : "none",
                borderBottom: (i < 3) ? "1px solid var(--border)" : "none",
                transition: "background 0.25s, box-shadow 0.25s",
                position:   "relative",
                cursor:     "default",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.background = "var(--bg-raised)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.background = "var(--bg-card)";
              }}
            >
              {/* Tag */}
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "24px" }}>
                <div
                  style={{
                    width:          "42px",
                    height:         "42px",
                    borderRadius:   "var(--radii-inner)",
                    background:     "var(--accent-dim)",
                    border:         "1px solid var(--accent-border)",
                    display:        "flex",
                    alignItems:     "center",
                    justifyContent: "center",
                    color:          "var(--accent)",
                  }}
                  aria-hidden="true"
                >
                  <Icon size={18} />
                </div>
                <span
                  style={{
                    fontFamily:    "var(--font-mono)",
                    fontSize:      "9px",
                    letterSpacing: "0.18em",
                    textTransform: "uppercase",
                    color:         tag === "New" ? "var(--accent)" : "var(--text-muted)",
                    border:        `1px solid ${tag === "New" ? "var(--accent-border)" : "var(--border)"}`,
                    padding:       "3px 10px",
                    borderRadius:  "100px",
                  }}
                >
                  {tag}
                </span>
              </div>

              <h3
                style={{
                  fontFamily:   "var(--font-sans)",
                  fontSize:     "16px",
                  fontWeight:   500,
                  color:        "var(--text)",
                  marginBottom: "10px",
                  lineHeight:   1.4,
                }}
              >
                {title}
              </h3>
              <p
                style={{
                  fontSize:   "13.5px",
                  fontWeight: 300,
                  color:      "var(--text-dim)",
                  lineHeight: 1.7,
                }}
              >
                {body}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
