/**
 * PricingSection
 * PURPOSE: Simple. Clear. CTA on every tier. No confusion.
 * ─────────────────────────────────────────────────────────────
 */

import Link from "next/link";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface PricingTier {
  name:        string;
  price:       string;
  period:      string;
  tagline:     string;
  features:    string[];
  cta:         string;
  ctaHref:     string;
  highlight:   boolean;
  badge?:      string;
}

const tiers: PricingTier[] = [
  {
    name:     "Proof Starter",
    price:    "$39",
    period:   "/mo",
    tagline:  "Untuk founder yang baru mulai pitching dengan data.",
    features: [
      "30 proof reports / month",
      "Ranking visualizer",
      "PDF export",
      "Shareable link",
      "2 users",
    ],
    cta:       "Start Free Trial",
    ctaHref:   "#early-access",
    highlight: false,
  },
  {
    name:      "Agency Pro",
    price:     "$79",
    period:    "/mo",
    tagline:   "Untuk agensi yang pitching aktif setiap minggu.",
    features:  [
      "Unlimited proof reports",
      "AI Overview Impact Map",
      "White-label output",
      "Multi-region support (90+ countries)",
      "5 users",
      "API access",
      "Priority support",
    ],
    cta:       "Get Agency Pro",
    ctaHref:   "#early-access",
    highlight: true,
    badge:     "Most Popular",
  },
  {
    name:     "Agency Elite",
    price:    "$149",
    period:   "/mo",
    tagline:  "Untuk agensi besar dengan volume pitching tinggi.",
    features: [
      "Everything in Agency Pro",
      "Custom branding & domain",
      "Team workspaces",
      "Webhook & Zapier integration",
      "Unlimited users",
      "Dedicated success manager",
      "SLA: 99.9% uptime",
    ],
    cta:       "Contact Sales",
    ctaHref:   "mailto:sales@octopilot.co",
    highlight: false,
  },
];

interface PricingSectionProps {
  className?: string;
}

export function PricingSection({ className }: PricingSectionProps) {
  return (
    <section
      id="pricing"
      aria-labelledby="pricing-heading"
      className={cn("section-pricing", className)}
      style={{
        padding:      "120px 40px",
        borderBottom: "1px solid var(--border)",
        background:   "var(--bg-raised)",
        position:     "relative",
        overflow:     "hidden",
      }}
    >
      <div
        aria-hidden="true"
        style={{
          position:   "absolute",
          inset:      0,
          pointerEvents: "none",
          background: "radial-gradient(ellipse 60% 50% at 50% 100%, rgba(255,99,8,0.05) 0%, transparent 70%)",
        }}
      />
      <div style={{ maxWidth: "var(--content-width)", margin: "0 auto", position: "relative", zIndex: 1 }}>
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: "72px" }}>
          <span className="section-label" style={{ display: "block", marginBottom: "20px" }}>Pricing</span>
          <h2
            id="pricing-heading"
            style={{
              fontFamily:  "var(--font-serif)",
              fontSize:    "clamp(32px, 4.5vw, 58px)",
              lineHeight:  0.97,
              fontWeight:  400,
              color:       "var(--text)",
              marginBottom: "16px",
            }}
          >
            Pilih cara kamu{" "}
            <em style={{ fontStyle: "italic", color: "rgba(240,240,238,0.38)" }}>masuk.</em>
          </h2>
          <p style={{ fontSize: "15px", fontWeight: 300, color: "var(--text-dim)", maxWidth: "440px", margin: "0 auto" }}>
            Semua plan termasuk 14-hari free trial. Tidak perlu kartu kredit untuk mulai.
          </p>
        </div>

        {/* Pricing grid */}
        <div
          role="list"
          aria-label="Pricing plans"
          style={{
            display:             "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            gap:                 "20px",
            alignItems:          "stretch",
          }}
        >
          {tiers.map(({ name, price, period, tagline, features, cta, ctaHref, highlight, badge }) => (
            <article
              key={name}
              role="listitem"
              className="card"
              style={{
                padding:      "40px 32px",
                display:      "flex",
                flexDirection: "column",
                gap:          "24px",
                border:       highlight ? "1px solid var(--accent-border)" : "1px solid var(--border)",
                background:   highlight ? "rgba(255,99,8,0.04)" : "var(--bg-card)",
                position:     "relative",
              }}
            >
              {/* Badge */}
              {badge && (
                <div
                  aria-label="Most popular plan"
                  style={{
                    position:      "absolute",
                    top:           "-1px",
                    right:         "24px",
                    fontFamily:    "var(--font-mono)",
                    fontSize:      "8px",
                    textTransform: "uppercase",
                    letterSpacing: "0.18em",
                    color:         "var(--bg)",
                    background:    "var(--accent)",
                    padding:       "4px 12px",
                    borderRadius:  "0 0 8px 8px",
                  }}
                >
                  {badge}
                </div>
              )}

              {/* Tier meta */}
              <div>
                <h3
                  style={{
                    fontFamily:   "var(--font-mono)",
                    fontSize:     "10px",
                    textTransform: "uppercase",
                    letterSpacing: "0.18em",
                    color:        "var(--text-muted)",
                    marginBottom: "8px",
                  }}
                >
                  {name}
                </h3>
                <div
                  style={{
                    display:    "flex",
                    alignItems: "baseline",
                    gap:        "4px",
                    marginBottom: "12px",
                  }}
                >
                  <span
                    style={{
                      fontFamily:  "var(--font-mono)",
                      fontSize:    "42px",
                      fontWeight:  700,
                      lineHeight:  1,
                      color:       "var(--text)",
                    }}
                  >
                    {price}
                  </span>
                  <span style={{ fontSize: "13px", color: "var(--text-muted)" }}>{period}</span>
                </div>
                <p style={{ fontSize: "13px", fontWeight: 300, color: "var(--text-dim)", lineHeight: 1.6 }}>
                  {tagline}
                </p>
              </div>

              {/* Features */}
              <ul
                aria-label={`${name} features`}
                style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "10px", flex: 1 }}
              >
                {features.map((f) => (
                  <li
                    key={f}
                    style={{
                      display:    "flex",
                      alignItems: "flex-start",
                      gap:        "10px",
                      fontSize:   "13px",
                      fontWeight: 300,
                      color:      "var(--text-dim)",
                      lineHeight: 1.6,
                    }}
                  >
                    <Check
                      size={14}
                      style={{ color: highlight ? "var(--accent)" : "var(--success)", marginTop: "3px", flexShrink: 0 }}
                      aria-hidden="true"
                    />
                    {f}
                  </li>
                ))}
              </ul>

              {/* CTA */}
              <Link
                href={ctaHref}
                className={highlight ? "btn btn-accent" : "btn btn-ghost"}
                style={{ justifyContent: "center", width: "100%" }}
                aria-label={`${cta} — ${name} plan`}
              >
                {cta}
              </Link>
            </article>
          ))}
        </div>

        {/* Lifetime deal teaser */}
        <div
          style={{
            marginTop:    "32px",
            textAlign:    "center",
            fontSize:     "13px",
            fontWeight:   300,
            color:        "var(--text-muted)",
          }}
        >
          Cari{" "}
          <Link
            href="#early-access"
            style={{ color: "var(--accent)", textDecoration: "underline", textDecorationColor: "var(--accent-border)" }}
          >
            Founding Member Lifetime Deal ($149 sekali bayar)
          </Link>
          ? Scroll ke bawah. 17/50 slot tersisa.
        </div>
      </div>
    </section>
  );
}
