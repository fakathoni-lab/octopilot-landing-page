/**
 * ProblemSection
 * PURPOSE: Force recognition of the pain. Founders should see
 * themselves in every row and feel compelled to scroll.
 * ─────────────────────────────────────────────────────────────
 */

import { cn } from "@/lib/utils";

const pains = [
  {
    id: "01",
    headline: "Kamu pitching tanpa bukti",
    body:
      "Prospek bilang 'nanti dulu' bukan karena mereka tidak butuh. Tapi karena kamu tidak menunjukkan masalah mereka dengan cukup jelas. Data di spreadsheet-mu tidak terasa nyata untuk mereka.",
  },
  {
    id: "02",
    headline: "Kamu mengemis akses yang tidak akan pernah datang",
    body:
      "Minta GA4? Tunggu. Minta GSC? Tunggu lebih lama. Di saat kamu menunggu izin, kompetitormu sudah menutup deal. Access-dependency adalah pembunuh konversi yang paling sering diabaikan.",
  },
  {
    id: "03",
    headline: "Manual audit: 45 menit untuk satu prospek",
    body:
      "Screenshot ranking, tabel di Google Sheets, copy-paste angka, format ulang, kirim email. Dan prospek masih bisa bilang: 'Data-nya kurang meyakinkan.' Waktu yang hilang tidak pernah kembali.",
  },
];

interface ProblemSectionProps {
  className?: string;
}

export function ProblemSection({ className }: ProblemSectionProps) {
  return (
    <section
      id="problem"
      aria-labelledby="problem-heading"
      className={cn("section-problem", className)}
      style={{
        padding:      "120px 40px",
        borderBottom: "1px solid var(--border)",
        position:     "relative",
        overflow:     "hidden",
      }}
    >
      {/* Section glow */}
      <div
        aria-hidden="true"
        style={{
          position:   "absolute",
          inset:      0,
          pointerEvents: "none",
          background: "radial-gradient(ellipse 60% 50% at 90% 50%, rgba(255,99,8,0.04) 0%, transparent 70%)",
        }}
      />

      <div
        style={{
          maxWidth:    "var(--content-width)",
          margin:      "0 auto",
          position:    "relative",
          zIndex:      1,
        }}
      >
        {/* Top label */}
        <div style={{ marginBottom: "72px" }}>
          <span className="section-label" style={{ display: "inline-block", marginBottom: "20px" }}>
            The Problem
          </span>
          <h2
            id="problem-heading"
            style={{
              fontFamily:    "var(--font-serif)",
              fontSize:      "clamp(34px, 5vw, 64px)",
              lineHeight:    0.97,
              fontWeight:    400,
              color:         "var(--text)",
              maxWidth:      "700px",
              marginBottom:  "20px",
            }}
          >
            Prospek tidak percaya{" "}
            <em style={{ fontStyle: "italic", color: "rgba(240,240,238,0.38)" }}>
              sampai mereka melihatnya.
            </em>
          </h2>
          <p
            style={{
              fontSize:   "16.5px",
              fontWeight: 300,
              color:      "var(--text-dim)",
              maxWidth:   "500px",
              lineHeight: 1.75,
            }}
          >
            Dan kamu tidak cukup baik dalam membuat mereka melihatnya — bukan karena
            hasil kerjamu jelek, tapi karena cara kamu mempresentasikan bukti sudah ketinggalan zaman.
          </p>
        </div>

        {/* Pain cards */}
        <div
          role="list"
          aria-label="Problem areas"
          style={{
            display:  "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
            gap:      "1px",
            border:   "1px solid var(--border)",
            borderRadius: "var(--radii-outer)",
            overflow: "hidden",
          }}
        >
          {pains.map((pain) => (
            <div
              key={pain.id}
              role="listitem"
              style={{
                padding:    "40px 36px",
                background: "var(--bg-card)",
                borderRight: "1px solid var(--border)",
                position:   "relative",
                transition: "background 0.25s",
                cursor:     "default",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.background = "var(--bg-raised)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.background = "var(--bg-card)";
              }}
            >
              {/* ID */}
              <span
                style={{
                  display:       "block",
                  fontFamily:    "var(--font-mono)",
                  fontSize:      "10px",
                  letterSpacing: "0.18em",
                  color:         "var(--accent)",
                  marginBottom:  "20px",
                  textTransform: "uppercase",
                }}
              >
                [{pain.id}]
              </span>

              {/* Headline */}
              <h3
                style={{
                  fontFamily:   "var(--font-serif)",
                  fontSize:     "clamp(22px, 2.5vw, 28px)",
                  fontWeight:   400,
                  lineHeight:   1.25,
                  color:        "var(--text)",
                  marginBottom: "16px",
                }}
              >
                {pain.headline}
              </h3>

              {/* Body */}
              <p
                style={{
                  fontSize:   "14.5px",
                  fontWeight: 300,
                  color:      "var(--text-dim)",
                  lineHeight: 1.75,
                }}
              >
                {pain.body}
              </p>

              {/* Bottom accent bar — reveals on hover */}
              <div
                aria-hidden="true"
                style={{
                  position:   "absolute",
                  bottom:     0,
                  left:       0,
                  right:      0,
                  height:     "2px",
                  background: "var(--accent)",
                  transform:  "scaleX(0)",
                  transformOrigin: "left",
                  transition: "transform 0.35s var(--ease-circ-out)",
                }}
                className="accent-bar"
              />
            </div>
          ))}
        </div>

        {/* Bottom tag */}
        <p
          style={{
            marginTop:  "40px",
            fontSize:   "13px",
            fontWeight: 300,
            color:      "var(--text-muted)",
            fontFamily: "var(--font-mono)",
            letterSpacing: "0.06em",
          }}
        >
          — Ini bukan masalah skill kamu. Ini masalah alat yang kamu pakai.
        </p>
      </div>
    </section>
  );
}
