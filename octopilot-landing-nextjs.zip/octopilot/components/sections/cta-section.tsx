/**
 * CTASection — Final conversion push
 * PURPOSE: Last chance. Maximum urgency. Email capture + lifetime deal.
 * ─────────────────────────────────────────────────────────────
 */

"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { ArrowRight, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

interface CTASectionProps {
  className?: string;
}

export function CTASection({ className }: CTASectionProps) {
  const [email, setEmail]     = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [error, setError]     = useState("");

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!email || !email.includes("@")) {
      setError("Masukkan email yang valid.");
      return;
    }
    setError("");
    // TODO: connect to Resend / ConvertKit API
    setSubmitted(true);
  }

  // Lifetime deal slot count
  const slotsTaken = 17;
  const slotsTotal = 50;
  const pct = Math.round((slotsTaken / slotsTotal) * 100);

  return (
    <section
      id="early-access"
      aria-labelledby="cta-heading"
      className={cn("section-cta", className)}
      style={{
        padding:      "120px 40px",
        borderBottom: "1px solid var(--border)",
        position:     "relative",
        overflow:     "hidden",
      }}
    >
      {/* Background glow */}
      <div
        aria-hidden="true"
        style={{
          position:   "absolute",
          inset:      0,
          pointerEvents: "none",
          background: `
            radial-gradient(ellipse 70% 50% at 50% 100%, rgba(255,99,8,0.1) 0%, transparent 65%),
            radial-gradient(ellipse 50% 40% at 50% 50%, rgba(255,99,8,0.04) 0%, transparent 70%)
          `,
        }}
      />

      <div style={{ maxWidth: "760px", margin: "0 auto", position: "relative", zIndex: 1, textAlign: "center" }}>
        {/* Eyebrow */}
        <span className="badge-accent" style={{ marginBottom: "32px", display: "inline-flex" }} aria-label="Only 33 founding member slots remaining">
          <Zap size={10} aria-hidden="true" />
          33 Founding Member Slot Tersisa
        </span>

        {/* Headline */}
        <h2
          id="cta-heading"
          style={{
            fontFamily:   "var(--font-serif)",
            fontSize:     "clamp(40px, 6vw, 88px)",
            lineHeight:   0.93,
            fontWeight:   400,
            color:        "var(--text)",
            marginBottom: "24px",
            marginTop:    "16px",
          }}
        >
          Kirim proof.<br />
          <em style={{ color: "var(--accent)", fontStyle: "normal" }}>Close client.</em>
        </h2>

        {/* Sub */}
        <p style={{ fontSize: "16px", fontWeight: 300, color: "var(--text-dim)", lineHeight: 1.75, marginBottom: "48px", maxWidth: "520px", margin: "0 auto 48px" }}>
          Bergabung sebagai Founding Member. Akses lifetime ke Octopilot seharga <strong style={{ color: "var(--text)", fontWeight: 500 }}>$149 sekali bayar</strong> — vs $948/tahun jika bayar bulanan.
        </p>

        {/* Email form */}
        {!submitted ? (
          <form
            onSubmit={handleSubmit}
            style={{
              display:      "flex",
              gap:          "8px",
              maxWidth:     "480px",
              margin:       "0 auto 20px",
              flexWrap:     "wrap",
            }}
            aria-label="Early access waitlist form"
          >
            <div style={{ flex: 1, minWidth: "240px" }}>
              <label htmlFor="email-input" className="sr-only">
                Email address
              </label>
              <input
                id="email-input"
                type="email"
                value={email}
                onChange={(e) => { setEmail(e.target.value); setError(""); }}
                placeholder="nama@company.com"
                required
                autoComplete="email"
                aria-label="Your work email"
                aria-describedby={error ? "email-error" : undefined}
                aria-invalid={!!error}
                style={{
                  width:         "100%",
                  height:        "var(--btn-height-lg)",
                  padding:       "0 18px",
                  background:    "var(--bg-raised)",
                  border:        `1px solid ${error ? "rgba(248,113,113,0.5)" : "var(--border-strong)"}`,
                  borderRadius:  "9999px",
                  color:         "var(--text)",
                  fontSize:      "14px",
                  fontFamily:    "var(--font-sans)",
                  outline:       "none",
                  transition:    "border-color 0.2s",
                }}
                onFocus={(e) => { if (!error) (e.target as HTMLInputElement).style.borderColor = "rgba(255,99,8,0.5)"; }}
                onBlur={(e)  => { if (!error) (e.target as HTMLInputElement).style.borderColor = "var(--border-strong)"; }}
              />
            </div>
            <button
              type="submit"
              className="btn btn-accent btn-lg"
              aria-label="Join the waitlist"
            >
              Secure My Slot
              <ArrowRight size={14} aria-hidden="true" />
            </button>
          </form>
        ) : (
          <div
            role="status"
            aria-live="polite"
            style={{
              display:      "flex",
              alignItems:   "center",
              justifyContent: "center",
              gap:          "12px",
              padding:      "20px 32px",
              background:   "rgba(34,197,94,0.08)",
              border:       "1px solid rgba(34,197,94,0.25)",
              borderRadius: "9999px",
              maxWidth:     "480px",
              margin:       "0 auto 20px",
              fontSize:     "14px",
              fontWeight:   400,
              color:        "#22c55e",
            }}
          >
            ✓ Kamu masuk. Cek email kamu untuk konfirmasi.
          </div>
        )}

        {/* Error message */}
        {error && (
          <p
            id="email-error"
            role="alert"
            style={{ color: "#f87171", fontSize: "12px", marginBottom: "8px" }}
          >
            {error}
          </p>
        )}

        {/* Trust signals */}
        <p style={{ fontSize: "12px", fontWeight: 300, color: "var(--text-muted)", marginBottom: "48px" }}>
          Gratis untuk coba · Tidak perlu kartu kredit · Cancel kapan saja
        </p>

        {/* Lifetime deal card */}
        <div
          style={{
            border:       "1px solid var(--accent-border)",
            borderRadius: "var(--radii-outer)",
            background:   "rgba(255,99,8,0.04)",
            padding:      "32px",
            textAlign:    "left",
          }}
          role="complementary"
          aria-label="Founding member lifetime deal"
        >
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "16px", marginBottom: "20px" }}>
            <div>
              <span
                style={{
                  fontFamily:    "var(--font-mono)",
                  fontSize:      "8px",
                  textTransform: "uppercase",
                  letterSpacing: "0.2em",
                  color:         "var(--accent)",
                  display:       "block",
                  marginBottom:  "8px",
                }}
              >
                Founding Member — 50 Slots Only
              </span>
              <h3
                style={{
                  fontFamily: "var(--font-serif)",
                  fontSize:   "28px",
                  fontWeight: 400,
                  color:      "var(--text)",
                  lineHeight: 1.2,
                }}
              >
                Lifetime Access — $149
                {" "}
                <span style={{ fontSize: "16px", fontWeight: 300, color: "var(--text-muted)", textDecoration: "line-through" }}>$948/yr</span>
              </h3>
            </div>
            <Link
              href="#"
              className="btn btn-accent"
              aria-label="Claim founding member lifetime access"
            >
              Claim My Slot →
            </Link>
          </div>

          {/* Slot progress bar */}
          <div style={{ marginBottom: "20px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: "10px", color: "var(--text-muted)", letterSpacing: "0.1em" }}>
                SLOTS CLAIMED
              </span>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: "10px", color: "var(--accent)", letterSpacing: "0.1em" }}>
                {slotsTaken}/{slotsTotal}
              </span>
            </div>
            <div
              role="progressbar"
              aria-valuenow={slotsTaken}
              aria-valuemin={0}
              aria-valuemax={slotsTotal}
              aria-label={`${slotsTaken} of ${slotsTotal} founding member slots claimed`}
              style={{
                height:       "4px",
                background:   "rgba(255,255,255,0.07)",
                borderRadius: "2px",
                overflow:     "hidden",
              }}
            >
              <div
                style={{
                  width:        `${pct}%`,
                  height:       "100%",
                  background:   "var(--accent)",
                  borderRadius: "2px",
                  transition:   "width 1s var(--ease-circ-out)",
                }}
              />
            </div>
          </div>

          {/* Perks */}
          <ul
            aria-label="Founding member benefits"
            style={{ listStyle: "none", display: "flex", flexWrap: "wrap", gap: "8px" }}
          >
            {[
              "Lifetime access Agency Pro",
              "All future features",
              "Founding Member badge",
              "Direct access ke team Octopilot",
              "Priority feature requests",
            ].map((perk) => (
              <li
                key={perk}
                style={{
                  fontFamily:    "var(--font-mono)",
                  fontSize:      "9px",
                  textTransform: "uppercase",
                  letterSpacing: "0.12em",
                  color:         "var(--text-dim)",
                  border:        "1px solid var(--border-strong)",
                  padding:       "4px 12px",
                  borderRadius:  "100px",
                }}
              >
                ✓ {perk}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
