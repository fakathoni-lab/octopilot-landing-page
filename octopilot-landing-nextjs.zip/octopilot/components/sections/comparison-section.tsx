/**
 * ComparisonSection
 * PURPOSE: De-position alternatives. Octopilot is the only one
 * that delivers proof without access dependency.
 * ─────────────────────────────────────────────────────────────
 */

import { CheckCircle2, XCircle, MinusCircle } from "lucide-react";
import { cn } from "@/lib/utils";

type TruthValue = true | false | "partial";

interface ComparisonRow {
  feature: string;
  description: string;
  octopilot: TruthValue;
  semrush:   TruthValue;
  manual:    TruthValue;
  ahrefs:    TruthValue;
}

const rows: ComparisonRow[] = [
  {
    feature:     "No access required",
    description: "Works without GA4, GSC, or any client auth",
    octopilot:   true,
    semrush:     false,
    manual:      false,
    ahrefs:      false,
  },
  {
    feature:     "< 60 second proof",
    description: "From domain input to shareable output",
    octopilot:   true,
    semrush:     "partial",
    manual:      false,
    ahrefs:      "partial",
  },
  {
    feature:     "Visual proof format",
    description: "Client-ready chart, not raw data table",
    octopilot:   true,
    semrush:     false,
    manual:      "partial",
    ahrefs:      false,
  },
  {
    feature:     "AI Overview detection",
    description: "Identify AI Overview impact on organic CTR",
    octopilot:   true,
    semrush:     false,
    manual:      false,
    ahrefs:      false,
  },
  {
    feature:     "White-label output",
    description: "Branded report with your agency logo",
    octopilot:   true,
    semrush:     false,
    manual:      true,
    ahrefs:      false,
  },
  {
    feature:     "Flat pricing",
    description: "No per-seat or per-domain pricing model",
    octopilot:   true,
    semrush:     false,
    manual:      true,
    ahrefs:      false,
  },
];

function StatusIcon({ val }: { val: TruthValue }) {
  if (val === true)      return <CheckCircle2 size={18} style={{ color: "#22c55e" }} aria-label="Yes" />;
  if (val === "partial") return <MinusCircle  size={18} style={{ color: "var(--accent)" }} aria-label="Partial" />;
  return                        <XCircle      size={18} style={{ color: "rgba(248,113,113,0.5)" }} aria-label="No" />;
}

const cols = [
  { key: "octopilot", label: "Octopilot", highlight: true  },
  { key: "semrush",   label: "SEMrush",   highlight: false },
  { key: "ahrefs",    label: "Ahrefs",    highlight: false },
  { key: "manual",    label: "Manual",    highlight: false },
] as const;

interface ComparisonSectionProps {
  className?: string;
}

export function ComparisonSection({ className }: ComparisonSectionProps) {
  return (
    <section
      id="comparison"
      aria-labelledby="comparison-heading"
      className={cn("section-comparison", className)}
      style={{
        padding:      "120px 40px",
        borderBottom: "1px solid var(--border)",
        position:     "relative",
        overflow:     "hidden",
      }}
    >
      <div style={{ maxWidth: "var(--content-width)", margin: "0 auto" }}>
        <div style={{ marginBottom: "64px" }}>
          <span className="section-label" style={{ display: "block", marginBottom: "20px" }}>Comparison</span>
          <h2
            id="comparison-heading"
            style={{
              fontFamily:  "var(--font-serif)",
              fontSize:    "clamp(32px, 4.5vw, 58px)",
              lineHeight:  0.97,
              fontWeight:  400,
              color:       "var(--text)",
              maxWidth:    "600px",
            }}
          >
            Kenapa bukan{" "}
            <em style={{ fontStyle: "italic", color: "rgba(240,240,238,0.38)" }}>
              yang lain.
            </em>
          </h2>
        </div>

        {/* Table */}
        <div
          style={{
            border:       "1px solid var(--border)",
            borderRadius: "var(--radii-outer)",
            overflow:     "hidden",
            overflowX:    "auto",
          }}
          role="region"
          aria-label="Feature comparison table"
        >
          <table
            style={{
              width:          "100%",
              borderCollapse: "collapse",
              minWidth:       "600px",
            }}
          >
            <thead>
              <tr style={{ borderBottom: "1px solid var(--border-strong)" }}>
                <th
                  scope="col"
                  style={{
                    textAlign:     "left",
                    padding:       "18px 28px",
                    fontFamily:    "var(--font-mono)",
                    fontSize:      "10px",
                    letterSpacing: "0.15em",
                    textTransform: "uppercase",
                    color:         "var(--text-muted)",
                    fontWeight:    400,
                    background:    "var(--bg-card)",
                    width:         "40%",
                  }}
                >
                  Feature
                </th>
                {cols.map(({ key, label, highlight }) => (
                  <th
                    key={key}
                    scope="col"
                    style={{
                      textAlign:     "center",
                      padding:       "18px 20px",
                      fontFamily:    "var(--font-mono)",
                      fontSize:      "10px",
                      letterSpacing: "0.15em",
                      textTransform: "uppercase",
                      color:         highlight ? "var(--accent)" : "var(--text-muted)",
                      fontWeight:    400,
                      background:    highlight ? "rgba(255,99,8,0.06)" : "var(--bg-card)",
                      borderLeft:    "1px solid var(--border)",
                    }}
                  >
                    {label}
                    {highlight && (
                      <span
                        style={{
                          display:       "block",
                          fontSize:      "7px",
                          letterSpacing: "0.2em",
                          color:         "var(--accent)",
                          opacity:       0.7,
                          marginTop:     "4px",
                        }}
                      >
                        ← Best
                      </span>
                    )}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => (
                <tr
                  key={row.feature}
                  style={{
                    borderBottom: i < rows.length - 1 ? "1px solid var(--border)" : "none",
                  }}
                >
                  <td style={{ padding: "22px 28px", background: "var(--bg-card)" }}>
                    <span style={{ fontSize: "14px", fontWeight: 500, color: "var(--text)", display: "block" }}>
                      {row.feature}
                    </span>
                    <span style={{ fontSize: "12px", fontWeight: 300, color: "var(--text-muted)" }}>
                      {row.description}
                    </span>
                  </td>
                  {cols.map(({ key, highlight }) => (
                    <td
                      key={key}
                      style={{
                        textAlign:  "center",
                        padding:    "22px 20px",
                        background: highlight ? "rgba(255,99,8,0.035)" : "var(--bg-card)",
                        borderLeft: "1px solid var(--border)",
                        verticalAlign: "middle",
                      }}
                    >
                      <StatusIcon val={row[key]} />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
