/**
 * UseCaseSection — Founder / Developer / Indie Hacker
 * PURPOSE: Create identity resonance. Make each persona feel seen.
 * ─────────────────────────────────────────────────────────────
 */

import { cn } from "@/lib/utils";

const personas = [
  {
    role:   "For the Founder",
    emoji:  "🏗",
    tagline: "Close clients, not spreadsheets.",
    body:    "Kamu pitching setiap minggu. Waktu untuk audit manual adalah waktu yang diambil dari product development. Octopilot mengubah setiap domain search menjadi closing ammunition — dalam hitungan menit.",
    bullets: [
      "Proof siap sebelum sales call dimulai",
      "Tidak perlu hire SEO analyst untuk validasi",
      "Pipeline velocity meningkat karena friction berkurang",
    ],
  },
  {
    role:   "For the Developer",
    emoji:  "⚡",
    tagline: "Ship proof. Not decks.",
    body:    "Kamu bisa build segalanya — tapi pitching ke non-tech client masih menyita waktu. Biarkan data bicara untuk kamu. Octopilot API-ready untuk integrasi ke workflow yang sudah ada.",
    bullets: [
      "API access untuk custom integration",
      "Webhook support untuk automation pipeline",
      "Export data mentah untuk custom reporting",
    ],
  },
  {
    role:   "For the Indie Hacker",
    emoji:  "🚀",
    tagline: "One tool. One price. Unlimited proof.",
    body:    "Kamu solo. Budget terbatas. Setiap tool harus earn its keep. Octopilot menggantikan kombinasi SEMrush export + manual formatting + Google Slides — dengan harga yang masuk akal untuk bootstrapper.",
    bullets: [
      "Pricing flat untuk unlimited proof generation",
      "No seat-based pricing — bayar untuk output, bukan user",
      "White-label untuk dijual kembali ke klien",
    ],
  },
];

interface UseCaseSectionProps {
  className?: string;
}

export function UseCaseSection({ className }: UseCaseSectionProps) {
  return (
    <section
      id="use-cases"
      aria-labelledby="usecase-heading"
      className={cn("section-usecases", className)}
      style={{
        padding:      "120px 40px",
        borderBottom: "1px solid var(--border)",
        background:   "var(--bg-raised)",
        position:     "relative",
        overflow:     "hidden",
      }}
    >
      <div style={{ maxWidth: "var(--content-width)", margin: "0 auto" }}>
        <div style={{ marginBottom: "72px" }}>
          <span className="section-label" style={{ display: "block", marginBottom: "20px" }}>Use Cases</span>
          <h2
            id="usecase-heading"
            style={{
              fontFamily:  "var(--font-serif)",
              fontSize:    "clamp(32px, 4.5vw, 58px)",
              lineHeight:  0.97,
              fontWeight:  400,
              color:       "var(--text)",
              maxWidth:    "600px",
            }}
          >
            Dibuat untuk builder
            {" "}
            <em style={{ fontStyle: "italic", color: "rgba(240,240,238,0.38)" }}>
              di semua stage.
            </em>
          </h2>
        </div>

        <div
          role="list"
          aria-label="Use cases by persona"
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
            gap:     "20px",
          }}
        >
          {personas.map(({ role, emoji, tagline, body, bullets }) => (
            <article
              key={role}
              role="listitem"
              className="card"
              style={{
                padding:  "40px 36px",
                display:  "flex",
                flexDirection: "column",
                gap:      "20px",
              }}
            >
              <div>
                <div
                  style={{
                    fontSize:     "28px",
                    marginBottom: "16px",
                  }}
                  aria-hidden="true"
                >
                  {emoji}
                </div>
                <span
                  style={{
                    fontFamily:    "var(--font-mono)",
                    fontSize:      "9px",
                    textTransform: "uppercase",
                    letterSpacing: "0.18em",
                    color:         "var(--text-muted)",
                    display:       "block",
                    marginBottom:  "10px",
                  }}
                >
                  {role}
                </span>
                <h3
                  style={{
                    fontFamily:   "var(--font-serif)",
                    fontSize:     "22px",
                    fontWeight:   400,
                    color:        "var(--text)",
                    marginBottom: "14px",
                    lineHeight:   1.25,
                  }}
                >
                  {tagline}
                </h3>
                <p style={{ fontSize: "13.5px", fontWeight: 300, color: "var(--text-dim)", lineHeight: 1.75 }}>
                  {body}
                </p>
              </div>

              <ul
                aria-label={`${role} benefits`}
                style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "8px" }}
              >
                {bullets.map((b) => (
                  <li
                    key={b}
                    style={{
                      display:    "flex",
                      alignItems: "flex-start",
                      gap:        "10px",
                      fontSize:   "13px",
                      fontWeight: 300,
                      color:      "var(--text-dim)",
                      lineHeight: 1.6,
                    }}
                  >
                    <span
                      aria-hidden="true"
                      style={{
                        color:     "var(--accent)",
                        fontFamily: "var(--font-mono)",
                        fontSize:  "11px",
                        marginTop: "3px",
                        flexShrink: 0,
                      }}
                    >
                      /
                    </span>
                    {b}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
