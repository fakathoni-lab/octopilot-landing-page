/**
 * SolutionSection
 * PURPOSE: Show the 3-step system. Mechanism clarity = conversion.
 * ─────────────────────────────────────────────────────────────
 */

import { cn } from "@/lib/utils";

const steps = [
  {
    num:     "01",
    title:   "Input Domain & Keywords",
    body:    "Masukkan domain prospek dan 3–5 keywords target. Tidak perlu akses apapun — Octopilot mengambil public ranking data secara real-time dari ratusan sumber.",
    tag:     "Input Layer",
    detail:  "Supports any domain · Google & Bing · 90+ countries",
  },
  {
    num:     "02",
    title:   "AI Generates Proof Report",
    body:    "Engine kami menganalisis posisi ranking, AI Overview presence, volatility trend, dan CTR impact. Output: visual proof document yang siap dikirim — dalam 47 detik rata-rata.",
    tag:     "AI Engine",
    detail:  "Avg. 47s generation · Visual ranking chart · AI Overview overlay",
  },
  {
    num:     "03",
    title:   "Send & Close",
    body:    "Copy link atau download PDF. Kirim ke prospek via email, WhatsApp, atau tampilkan langsung di Zoom. Data berbicara. Prospek percaya. Deal lebih mudah.",
    tag:     "Delivery Layer",
    detail:  "PDF export · Shareable link · Embed-ready · Branded output",
  },
];

interface SolutionSectionProps {
  className?: string;
}

export function SolutionSection({ className }: SolutionSectionProps) {
  return (
    <section
      id="how"
      aria-labelledby="solution-heading"
      className={cn("section-solution", className)}
      style={{
        padding:      "120px 40px",
        borderBottom: "1px solid var(--border)",
        background:   "var(--bg-raised)",
        position:     "relative",
        overflow:     "hidden",
      }}
    >
      <div
        style={{ maxWidth: "var(--content-width)", margin: "0 auto", position: "relative", zIndex: 1 }}
      >
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "80px", flexWrap: "wrap", gap: "24px" }}>
          <div style={{ maxWidth: "560px" }}>
            <span className="section-label" style={{ display: "block", marginBottom: "20px" }}>
              How it Works
            </span>
            <h2
              id="solution-heading"
              style={{
                fontFamily:    "var(--font-serif)",
                fontSize:      "clamp(32px, 4.5vw, 58px)",
                lineHeight:    0.97,
                fontWeight:    400,
                color:         "var(--text)",
                marginBottom:  "16px",
              }}
            >
              Tiga langkah dari{" "}
              <em style={{ fontStyle: "italic", color: "rgba(240,240,238,0.38)" }}>
                curious
              </em>{" "}
              ke{" "}
              <em style={{ color: "var(--accent)", fontStyle: "normal" }}>
                closed.
              </em>
            </h2>
          </div>
          <p style={{ fontSize: "14.5px", fontWeight: 300, color: "var(--text-dim)", maxWidth: "300px", lineHeight: 1.75, textAlign: "right" }}>
            Didesain untuk kecepatan. Setiap langkah menghilangkan satu alasan prospek untuk berkata "nanti dulu."
          </p>
        </div>

        {/* Steps */}
        <div
          role="list"
          aria-label="How Octopilot works"
          style={{ display: "flex", flexDirection: "column", gap: "1px", border: "1px solid var(--border)", borderRadius: "var(--radii-outer)", overflow: "hidden" }}
        >
          {steps.map((step, i) => (
            <div
              key={step.num}
              role="listitem"
              style={{
                display:     "grid",
                gridTemplateColumns: "auto 1fr auto",
                alignItems:  "start",
                gap:         "40px",
                padding:     "40px 40px",
                background:  "var(--bg-card)",
                borderBottom: i < steps.length - 1 ? "1px solid var(--border)" : "none",
                transition:  "background 0.25s",
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "#111"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "var(--bg-card)"; }}
              className="solution-row"
            >
              {/* Step number */}
              <div
                style={{
                  fontFamily:    "var(--font-mono)",
                  fontSize:      "13px",
                  fontWeight:    700,
                  color:         "var(--accent)",
                  letterSpacing: "0.05em",
                  paddingTop:    "4px",
                  minWidth:      "40px",
                }}
                aria-label={`Step ${step.num}`}
              >
                {step.num}
              </div>

              {/* Content */}
              <div>
                <span
                  style={{
                    display:       "inline-block",
                    fontFamily:    "var(--font-mono)",
                    fontSize:      "9px",
                    letterSpacing: "0.18em",
                    textTransform: "uppercase",
                    color:         "var(--text-muted)",
                    border:        "1px solid var(--border)",
                    padding:       "3px 10px",
                    borderRadius:  "100px",
                    marginBottom:  "14px",
                  }}
                >
                  {step.tag}
                </span>
                <h3
                  style={{
                    fontFamily:   "var(--font-serif)",
                    fontSize:     "clamp(24px, 2.8vw, 30px)",
                    fontWeight:   400,
                    lineHeight:   1.2,
                    color:        "var(--text)",
                    marginBottom: "12px",
                  }}
                >
                  {step.title}
                </h3>
                <p style={{ fontSize: "14.5px", fontWeight: 300, color: "var(--text-dim)", lineHeight: 1.75, maxWidth: "480px" }}>
                  {step.body}
                </p>
              </div>

              {/* Detail tag — right side */}
              <p
                style={{
                  fontFamily:    "var(--font-mono)",
                  fontSize:      "9.5px",
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  color:         "var(--text-muted)",
                  textAlign:     "right",
                  lineHeight:    2,
                  minWidth:      "220px",
                  paddingTop:    "4px",
                }}
                className="hidden lg:block"
              >
                {step.detail.split(" · ").map((d) => (
                  <span key={d} style={{ display: "block" }}>/ {d}</span>
                ))}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
