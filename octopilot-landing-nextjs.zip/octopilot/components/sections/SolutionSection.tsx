import { Reveal } from "@/components/ui/reveal";

interface Step {
  num:    string;
  icon:   string;
  title:  string;
  body:   string;
  detail: string;
}

const STEPS: Step[] = [
  {
    num:    "Step 01",
    icon:   "💡",
    title:  "Describe your goal",
    body:   "Drop in your idea — a sentence, a paragraph, or a brain dump. Octopilot's AI reads context, infers scope, and asks only the clarifying questions that actually matter.",
    detail: "Plain text · No templates · < 2 minutes",
  },
  {
    num:    "Step 02",
    icon:   "🗺️",
    title:  "Get a structured plan",
    body:   "Instantly generates a prioritized execution roadmap: milestones, tasks, dependencies, and time estimates — calibrated to your team size and stated velocity.",
    detail: "Auto-prioritized · Dependency-aware · Fully editable",
  },
  {
    num:    "Step 03",
    icon:   "🚀",
    title:  "Execute and adapt",
    body:   "The engine tracks your progress, surfaces blockers before they cascade, and re-prioritizes dynamically. When scope changes, the plan changes with it — automatically.",
    detail: "Real-time tracking · Auto re-prioritize · Daily AI brief",
  },
];

export function SolutionSection() {
  return (
    <section
      id="solution"
      aria-labelledby="solution-heading"
      className="section-py bg-[#0d0d0f] border-t border-b border-white/[0.06]"
    >
      <div className="container mx-auto">

        {/* ── Header ── */}
        <div className="text-center mb-20">
          <Reveal>
            <div className="section-eyebrow mb-5 inline-flex">How It Works</div>
          </Reveal>
          <Reveal delay={1}>
            <h2
              id="solution-heading"
              className="text-[40px] sm:text-[56px] font-extrabold leading-[1.04] tracking-[-0.035em] text-ink"
            >
              Three steps.
              <br />
              <span className="text-brand-gradient">One execution engine.</span>
            </h2>
          </Reveal>
          <Reveal delay={2}>
            <p className="mt-5 max-w-[460px] mx-auto text-[16px] font-light text-ink-muted leading-relaxed">
              Octopilot connects strategy to execution in a single workflow.
              No configuration. No integration hell. Just build.
            </p>
          </Reveal>
        </div>

        {/* ── Steps grid ── */}
        <div className="grid grid-cols-1 md:grid-cols-3 border border-white/[0.07] rounded-2xl overflow-hidden">
          {STEPS.map(({ num, icon, title, body, detail }, i) => (
            <Reveal key={num} delay={(i) as 0 | 1 | 2}>
              <article
                className={[
                  "relative p-10 bg-[#080809] transition-colors duration-200 hover:bg-[#0f1012]",
                  i < STEPS.length - 1 ? "border-b md:border-b-0 md:border-r border-white/[0.07]" : "",
                ].join(" ")}
                aria-label={title}
              >
                {/* Step number */}
                <div className="flex items-center gap-3 mb-8">
                  <span className="text-[10px] font-mono tracking-[0.14em] text-ink-faint">
                    {num}
                  </span>
                  <div className="flex-1 h-px bg-gradient-to-r from-white/[0.07] to-transparent" />
                </div>

                {/* Icon tile */}
                <div
                  aria-hidden
                  className="h-13 w-13 rounded-xl border border-white/[0.07] bg-white/[0.03] flex items-center justify-center text-2xl mb-6 transition-colors group-hover:border-brand/30"
                  style={{ height: "52px", width: "52px" }}
                >
                  {icon}
                </div>

                <h3 className="text-[20px] font-bold tracking-[-0.02em] text-ink mb-3">
                  {title}
                </h3>
                <p className="text-[13.5px] text-ink-muted leading-[1.72] mb-5">
                  {body}
                </p>
                <p className="text-[11px] font-mono tracking-[0.06em] text-ink-faint">
                  {detail}
                </p>

                {/* Connector arrow (desktop) */}
                {i < STEPS.length - 1 && (
                  <div
                    aria-hidden
                    className="hidden md:flex absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 z-10 h-8 w-8 rounded-full border border-white/[0.1] bg-[#080809] items-center justify-center text-ink-faint text-sm"
                  >
                    →
                  </div>
                )}
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
