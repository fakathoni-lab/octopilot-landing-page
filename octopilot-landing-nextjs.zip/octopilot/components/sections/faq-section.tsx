/**
 * FAQSection — Accordion FAQ
 * PURPOSE: Kill remaining objections with specificity.
 * ─────────────────────────────────────────────────────────────
 */

"use client";

import { useState } from "react";
import { Plus, Minus } from "lucide-react";
import { cn } from "@/lib/utils";

const faqs = [
  {
    q: "Octopilot butuh akses GA4 atau Google Search Console dari prospek?",
    a: "Tidak. Sama sekali tidak. Octopilot menggunakan public ranking data yang dikumpulkan dari ratusan sumber secara legal dan real-time. Kamu tidak perlu meminta akses apapun dari prospek — inilah yang membedakan kami dari semua tool lain.",
  },
  {
    q: "Seberapa akurat data rankingnya?",
    a: "Akurasi kami untuk posisi ranking top-100 berada di kisaran 93–97% dibanding data aktual GSC. Untuk pitching purposes, akurasi ini lebih dari cukup. Proof yang kamu kirimkan akan mencerminkan kondisi nyata prospek secara signifikan.",
  },
  {
    q: "Berapa lama setup-nya?",
    a: "Rata-rata pengguna pertama mereka selesai dalam 4 menit — mulai dari daftar akun hingga proof pertama tergenerate dan siap dikirim ke prospek.",
  },
  {
    q: "Apakah saya bisa white-label output untuk klien?",
    a: "Ya, tersedia di plan Agency Pro ke atas. Logo agensi kamu akan muncul di setiap proof document. Kamu juga bisa custom domain untuk shareable link.",
  },
  {
    q: "Data apa saja yang tersedia dalam proof report?",
    a: "Setiap proof report mencakup: posisi ranking per keyword, trend 30-hari, CTR estimate, AI Overview presence & impact, top competitor positions, dan narrative summary yang ditulis oleh AI — semua dalam satu halaman visual.",
  },
  {
    q: "Apakah ada free trial?",
    a: "Ya. Semua plan termasuk 14-hari free trial tanpa kartu kredit. Kamu bisa generate hingga 5 proof reports selama trial. Jika bergabung sebagai Founding Member, akses lifetime dimulai langsung tanpa trial period.",
  },
  {
    q: "Apakah Octopilot support bahasa Indonesia?",
    a: "Ya. Proof output tersedia dalam English dan Bahasa Indonesia. Kamu bisa switch bahasa per-report, ideal untuk pitching klien lokal maupun internasional dari satu tool yang sama.",
  },
];

interface FAQSectionProps {
  className?: string;
}

export function FAQSection({ className }: FAQSectionProps) {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section
      id="faq"
      aria-labelledby="faq-heading"
      className={cn("section-faq", className)}
      style={{
        padding:      "120px 40px",
        borderBottom: "1px solid var(--border)",
        position:     "relative",
        overflow:     "hidden",
      }}
    >
      <div style={{ maxWidth: "var(--content-width)", margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 2fr", gap: "80px", alignItems: "start" }} className="faq-grid">
        {/* Left: Header */}
        <div style={{ position: "sticky", top: "calc(var(--nav-height) + 40px)" }}>
          <span className="section-label" style={{ display: "block", marginBottom: "20px" }}>FAQ</span>
          <h2
            id="faq-heading"
            style={{
              fontFamily:   "var(--font-serif)",
              fontSize:     "clamp(28px, 3.5vw, 48px)",
              lineHeight:   1.05,
              fontWeight:   400,
              color:        "var(--text)",
              marginBottom: "16px",
            }}
          >
            Pertanyaan yang wajar
            {" "}
            <em style={{ fontStyle: "italic", color: "rgba(240,240,238,0.38)" }}>
              untuk ditanyakan.
            </em>
          </h2>
          <p style={{ fontSize: "14px", fontWeight: 300, color: "var(--text-dim)", lineHeight: 1.75 }}>
            Masih punya pertanyaan lain?{" "}
            <a href="mailto:hello@octopilot.co" style={{ color: "var(--accent)", textDecoration: "underline" }}>
              Email kami
            </a>
            .
          </p>
        </div>

        {/* Right: Accordion */}
        <dl
          style={{ display: "flex", flexDirection: "column", gap: "1px", border: "1px solid var(--border)", borderRadius: "var(--radii-outer)", overflow: "hidden" }}
          role="list"
          aria-label="FAQ items"
        >
          {faqs.map(({ q, a }, i) => {
            const isOpen = open === i;
            return (
              <div
                key={i}
                role="listitem"
                style={{
                  background:   "var(--bg-card)",
                  borderBottom: i < faqs.length - 1 ? "1px solid var(--border)" : "none",
                }}
              >
                <dt>
                  <button
                    type="button"
                    onClick={() => setOpen(isOpen ? null : i)}
                    aria-expanded={isOpen}
                    aria-controls={`faq-answer-${i}`}
                    style={{
                      width:          "100%",
                      display:        "flex",
                      alignItems:     "center",
                      justifyContent: "space-between",
                      gap:            "16px",
                      padding:        "24px 28px",
                      background:     "none",
                      border:         "none",
                      cursor:         "pointer",
                      textAlign:      "left",
                      color:          "var(--text)",
                      fontSize:       "15px",
                      fontWeight:     400,
                      lineHeight:     1.5,
                      fontFamily:     "var(--font-sans)",
                      transition:     "color 0.2s",
                    }}
                  >
                    <span>{q}</span>
                    <span
                      aria-hidden="true"
                      style={{
                        flexShrink: 0,
                        color:      isOpen ? "var(--accent)" : "var(--text-muted)",
                        transition: "color 0.2s",
                      }}
                    >
                      {isOpen ? <Minus size={16} /> : <Plus size={16} />}
                    </span>
                  </button>
                </dt>
                {isOpen && (
                  <dd
                    id={`faq-answer-${i}`}
                    style={{
                      padding:    "0 28px 24px",
                      fontSize:   "14px",
                      fontWeight: 300,
                      color:      "var(--text-dim)",
                      lineHeight: 1.75,
                    }}
                  >
                    {a}
                  </dd>
                )}
              </div>
            );
          })}
        </dl>
      </div>
    </section>
  );
}
