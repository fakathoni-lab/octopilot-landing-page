"use client";

import { useEffect } from "react";
import Link from "next/link";
import { ArrowRight, Star, Users, Zap } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge, PulseDot } from "@/components/ui/badge";

/* ── Animation helpers ─────────────────────────────── */
const ease = [0.22, 1, 0.36, 1] as const;

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 22 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.65, ease, delay },
});

/* ── Background: grid + radial glow ───────────────── */
function HeroBg() {
  return (
    <div aria-hidden className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Grid lines */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.025) 1px, transparent 1px)",
          backgroundSize: "72px 72px",
          maskImage: "radial-gradient(ellipse 85% 85% at 50% 50%, black 25%, transparent 80%)",
          WebkitMaskImage: "radial-gradient(ellipse 85% 85% at 50% 50%, black 25%, transparent 80%)",
        }}
      />
      {/* Warm top glow */}
      <div className="absolute top-[-15%] left-1/2 -translate-x-1/2 h-[640px] w-[900px] rounded-full bg-brand opacity-[0.07] blur-[140px] animate-breathe" />
      {/* Cool bottom-right accent */}
      <div className="absolute bottom-0 right-[-5%] h-[420px] w-[520px] rounded-full bg-blue-500 opacity-[0.04] blur-[120px]" />
    </div>
  );
}

/* ── Floating terminal widget ──────────────────────── */
function TerminalWidget() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.96 }}
      animate={{ opacity: 1, y: 0,  scale: 1 }}
      transition={{ delay: 0.9, duration: 0.8, ease }}
      className="hidden xl:block absolute right-0 top-1/2 -translate-y-[55%] w-[364px]"
      aria-hidden
    >
      <div className="rounded-xl border border-white/[0.09] bg-[#101113]/95 backdrop-blur-sm shadow-[0_40px_100px_rgba(0,0,0,0.55)] overflow-hidden">
        {/* Title bar */}
        <div className="flex items-center gap-1.5 px-4 py-3 border-b border-white/[0.06] bg-white/[0.02]">
          <div className="h-2.5 w-2.5 rounded-full bg-[#FF5F57]" />
          <div className="h-2.5 w-2.5 rounded-full bg-[#FEBC2E]" style={{ marginLeft: "5px" }} />
          <div className="h-2.5 w-2.5 rounded-full bg-[#28C840]" style={{ marginLeft: "5px" }} />
          <span className="ml-3 text-[11px] font-mono text-ink-faint">
            octopilot — execution engine
          </span>
        </div>

        {/* Terminal body */}
        <div className="p-5 font-mono text-[12.5px] leading-[1.9] space-y-0.5">
          <div><span className="text-ink-faint">$ </span><span className="text-ink">octopilot init &quot;SaaS landing page&quot;</span></div>
          <div className="text-brand mt-1">▸  Analyzing project scope...</div>
          <div className="text-ink-muted">   ✓ 24 tasks identified</div>
          <div className="text-ink-muted">   ✓ Dependencies mapped</div>
          <div className="text-ink-muted">   ✓ Priorities calculated</div>
          <div className="text-ok mt-0.5">   ✓ Execution plan ready — 6 sprints</div>
          <div className="mt-2"><span className="text-ink-faint">$ </span><span className="text-ink">octopilot run --sprint 1</span></div>
          <div className="text-brand">▸  Executing sprint 1...</div>
          <div className="text-ink-muted">   [██████████░░░░░] 68%</div>
          <div className="mt-2 flex items-center gap-1">
            <span className="text-ink-faint">$ </span>
            <span className="inline-block h-[13px] w-[7px] bg-brand animate-blink" />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

/* ── Avatar cluster + stats ────────────────────────── */
function SocialProofRow() {
  const AVATARS = ["RA", "MT", "SK", "LP"];
  const STATS = [
    { icon: Users, value: "2,400+", label: "on waitlist" },
    { icon: Star,  value: "4.9 / 5", label: "rating" },
    { icon: Zap,   value: "10×",    label: "faster" },
  ];

  return (
    <motion.div
      {...fadeUp(0.72)}
      className="flex flex-wrap items-center gap-5 pt-8 mt-8 border-t border-white/[0.07]"
    >
      {/* Avatars */}
      <div className="flex items-center gap-3">
        <div className="flex -space-x-2">
          {AVATARS.map((init) => (
            <div
              key={init}
              className="h-8 w-8 rounded-full bg-gradient-to-br from-white/10 to-white/[0.04] border-2 border-[#080809] flex items-center justify-center text-[10px] font-semibold text-ink-muted"
            >
              {init}
            </div>
          ))}
          <div className="h-8 w-8 rounded-full bg-white/[0.06] border-2 border-[#080809] flex items-center justify-center text-[9px] font-semibold text-ink-faint">
            +43
          </div>
        </div>
        <span className="text-sm text-ink-faint">joined this week</span>
      </div>

      <div className="h-4 w-px bg-white/[0.08]" />

      {/* Stat pills */}
      {STATS.map(({ icon: Icon, value, label }) => (
        <div key={label} className="flex items-center gap-1.5">
          <Icon className="h-3.5 w-3.5 text-brand/70" aria-hidden />
          <span className="text-sm font-semibold text-ink">{value}</span>
          <span className="text-sm text-ink-faint">{label}</span>
        </div>
      ))}
    </motion.div>
  );
}

/* ── Hero Section ──────────────────────────────────── */
export function HeroSection() {
  return (
    <section
      id="hero"
      aria-label="Hero"
      className="relative min-h-screen flex flex-col justify-center overflow-hidden pt-20 pb-16"
    >
      <HeroBg />
      <TerminalWidget />

      <div className="container mx-auto relative z-10">
        <div className="max-w-[760px]">

          {/* ── Eyebrow badge ── */}
          <motion.div {...fadeUp(0)} className="mb-7">
            <Badge variant="brand">
              <PulseDot color="brand" />
              Early Access — 47 Founding Spots Remaining
            </Badge>
          </motion.div>

          {/* ── Headline ── */}
          <motion.h1
            {...fadeUp(0.12)}
            className="text-[52px] sm:text-[64px] lg:text-[78px] font-extrabold leading-[1.03] tracking-[-0.04em] text-ink"
          >
            The AI Execution Engine
            <br />
            <span className="text-brand-gradient">Builders Actually Use.</span>
          </motion.h1>

          {/* ── Subheadline ── */}
          <motion.p
            {...fadeUp(0.24)}
            className="mt-6 max-w-[520px] text-[17px] font-light leading-[1.75] text-ink-muted"
          >
            Stop juggling 12 tools to stay unblocked.
            Octopilot turns your raw idea into an adaptive execution plan,
            tracks progress, and tells you exactly what to build next.
          </motion.p>

          {/* ── CTA row ── */}
          <motion.div
            {...fadeUp(0.34)}
            className="mt-9 flex flex-wrap items-center gap-3"
          >
            <Button variant="primary" size="xl" asChild>
              <Link href="#early-access">
                Start Building Free
                <ArrowRight className="h-4 w-4" aria-hidden />
              </Link>
            </Button>
            <Button variant="secondary" size="xl" asChild>
              <Link href="#solution">See How It Works</Link>
            </Button>
          </motion.div>

          {/* ── Fine print ── */}
          <motion.p
            {...fadeUp(0.42)}
            className="mt-4 text-[12px] font-mono tracking-wide text-ink-faint"
          >
            No credit card · Free tier forever · Setup in 4 minutes
          </motion.p>

          {/* ── Social proof ── */}
          <SocialProofRow />
        </div>
      </div>

      {/* Bottom fade */}
      <div
        aria-hidden
        className="pointer-events-none absolute bottom-0 inset-x-0 h-28 bg-gradient-to-t from-[#080809] to-transparent"
      />
    </section>
  );
}
