import { Reveal } from "@/components/ui/reveal";

interface PainCard {
  num: string;
  icon: string;
  title: string;
  desc: string;
}

const PAINS: PainCard[] = [
  {
    num:   "01",
    icon:  "🔀",
    title: "Context-switching destroys momentum",
    desc:  "Notion for docs. Linear for tasks. Slack for updates. ChatGPT for thinking. You're managing tools more than building product.",
  },
  {
    num:   "02",
    icon:  "🌀",
    title: "AI assistants advise — they don't execute",
    desc:  "ChatGPT gives you a plan. Copilot writes one function. Neither connects the dots, tracks progress, or knows what needs to happen tomorrow.",
  },
  {
    num:   "03",
    icon:  "⏳",
    title: "Deadlines slip, priorities drift",
    desc:  "Without a system that adapts in real-time, your sprint plan becomes a fantasy by day three. Scope expands quietly. Momentum dies slowly.",
  },
];

export function ProblemSection() {
  return (
    <section
      id="problem"
      aria-labelledby="problem-heading"
      className="section-py border-t border-white/[0.06]"
    >
      <div className="container mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">

          {/* ── Left: headline + quote ── */}
          <div>
            <Reveal>
              <div className="section-eyebrow mb-5">The Problem</div>
            </Reveal>
            <Reveal delay={1}>
              <h2
                id="problem-heading"
                className="text-[40px] sm:text-[52px] font-extrabold leading-[1.06] tracking-[-0.03em] text-ink mb-6"
              >
                Builders don&apos;t fail
                from lack of ideas.
                <br />
                <span className="text-brand-gradient">
                  They fail from lack of execution.
                </span>
              </h2>
            </Reveal>
            <Reveal delay={2}>
              <p className="text-[16px] font-light leading-relaxed text-ink-muted mb-8 max-w-[460px]">
                You know what to build. But between context-switching,
                tool overload, and losing track of what&apos;s actually next —
                momentum dies before anything ships.
              </p>
            </Reveal>
            <Reveal delay={3}>
              <blockquote className="border-l-2 border-brand pl-5">
                <p className="text-[15px] italic text-ink-muted leading-relaxed">
                  &ldquo;I had the idea, the time, and the skills. What I lacked
                  was a system that kept me moving without friction.&rdquo;
                </p>
                <footer className="mt-3 text-[11px] font-mono text-ink-faint">
                  — Indie hacker, $0 → $8K MRR in 90 days
                </footer>
              </blockquote>
            </Reveal>
          </div>

          {/* ── Right: pain cards ── */}
          <div className="flex flex-col gap-3.5">
            {PAINS.map(({ num, icon, title, desc }, i) => (
              <Reveal key={num} delay={(i + 1) as 1 | 2 | 3}>
                <article
                  className="flex items-start gap-5 p-6 rounded-xl border border-white/[0.07] bg-[#0f1012] transition-all duration-200 hover:border-white/[0.11] hover:bg-[#131416] group"
                  aria-label={title}
                >
                  {/* Icon tile */}
                  <div
                    aria-hidden
                    className="h-11 w-11 rounded-lg border border-white/[0.07] bg-white/[0.03] flex items-center justify-center text-xl flex-shrink-0 group-hover:border-brand/30 transition-colors"
                  >
                    {icon}
                  </div>
                  <div>
                    <p className="text-[10px] font-mono text-ink-faint tracking-[0.12em] mb-1.5">
                      {num}
                    </p>
                    <h3 className="text-[15px] font-semibold tracking-[-0.01em] text-ink mb-1.5">
                      {title}
                    </h3>
                    <p className="text-[13px] text-ink-muted leading-[1.65]">
                      {desc}
                    </p>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
