/**
 * HeroSection — Octopilot Landing Page
 * ─────────────────────────────────────────────────────────────
 * PURPOSE:
 *   Above-the-fold section. One job: make the user feel the pain,
 *   see the solution, and click CTA before reading another word.
 *
 * STRUCTURE:
 *   Nav → Eyebrow badge → H1 (serif) → Sub → CTAs → Social proof
 *   Background: animated starfield canvas + grid overlay + radial glow
 *
 * ANIMATIONS (Framer Motion):
 *   - Staggered reveal: eyebrow → h1 → sub → ctas → social proof
 *   - Each element: fade-up with 0.1s stagger
 *   - Starfield: canvas, requestAnimationFrame
 *   - Announcement bar: CSS ticker (no JS)
 *
 * COPY RATIONALE:
 *   Headline triggers professional shame immediately (pain-first hook).
 *   Subheadline introduces unique mechanism (no permission required).
 *   Primary CTA: zero-friction (free, no card).
 *   Secondary CTA: see proof first (meets skeptics where they are).
 *   Social proof badge: creates FOMO + validation.
 * ─────────────────────────────────────────────────────────────
 */

"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { ArrowRight, Zap, Shield } from "lucide-react";
import { cn } from "@/lib/utils";

// ── Type ──────────────────────────────────────────────────────
interface HeroSectionProps {
  className?: string;
}

// ── Sub-components ───────────────────────────────────────────

/** Animated live ticker badge */
function LiveBadge() {
  return (
    <span className="badge-accent animate-pulse-badge" aria-label="Early access now open">
      <span
        aria-hidden="true"
        style={{
          display: "inline-block",
          width: 6,
          height: 6,
          borderRadius: "50%",
          background: "var(--accent)",
        }}
      />
      Early Access Open — 17 of 50 slots
    </span>
  );
}

/** Social proof row — subtle validation strip */
function SocialProofRow() {
  const items = [
    { num: "47s",  label: "Avg. proof time" },
    { num: "2.3×", label: "Higher close rate" },
    { num: "83%",  label: "Prospects engaged" },
    { num: "$0",   label: "To join waitlist"  },
  ];

  return (
    <div
      className="flex flex-wrap items-center gap-x-8 gap-y-3"
      role="list"
      aria-label="Product statistics"
    >
      {items.map((item, i) => (
        <div key={i} role="listitem" className="flex items-baseline gap-2">
          <span
            style={{
              fontFamily: "var(--font-mono)",
              fontSize: "1.125rem",
              fontWeight: 700,
              color: "var(--text)",
              lineHeight: 1,
            }}
          >
            {item.num}
          </span>
          <span
            style={{
              fontSize: "0.75rem",
              fontWeight: 300,
              color: "var(--text-dim)",
            }}
          >
            {item.label}
          </span>
        </div>
      ))}
    </div>
  );
}

/** Starfield canvas background */
function StarfieldCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let W = 0, H = 0;
    let animId: number;

    interface Star {
      x: number; y: number; r: number;
      speed: number; phase: number;
    }
    let stars: Star[] = [];

    function resize() {
      if (!canvas) return;
      W = canvas.width  = canvas.offsetWidth;
      H = canvas.height = canvas.offsetHeight;
      stars = Array.from({ length: 120 }, () => ({
        x:     Math.random() * W,
        y:     Math.random() * H,
        r:     Math.random() * 1.15 + 0.1,
        speed: Math.random() * 0.004 + 0.001,
        phase: Math.random() * Math.PI * 2,
      }));
    }

    function draw(t: number) {
      if (!ctx) return;
      ctx.clearRect(0, 0, W, H);
      for (const s of stars) {
        const alpha = 0.08 + 0.22 * Math.sin(t * 0.001 * s.speed * 250 + s.phase);
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(240,240,238,${alpha.toFixed(3)})`;
        ctx.fill();
      }
      animId = requestAnimationFrame(draw);
    }

    const ro = new ResizeObserver(resize);
    if (canvas.parentElement) ro.observe(canvas.parentElement);
    resize();
    animId = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(animId);
      ro.disconnect();
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      style={{
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        pointerEvents: "none",
        zIndex: 0,
      }}
    />
  );
}

// ── Nav ───────────────────────────────────────────────────────
function SiteNav() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 12);
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const links = [
    { label: "How it works", href: "#how"      },
    { label: "Features",     href: "#features"  },
    { label: "Pricing",      href: "#pricing"   },
    { label: "FAQ",          href: "#faq"       },
  ];

  return (
    <nav
      role="navigation"
      aria-label="Main navigation"
      style={{
        position:       "fixed",
        top:            0,
        left:           0,
        right:          0,
        zIndex:         200,
        display:        "flex",
        alignItems:     "center",
        justifyContent: "space-between",
        padding:        "0 40px",
        height:         "var(--nav-height)",
        borderBottom:   scrolled ? "1px solid var(--border)" : "1px solid transparent",
        background:     scrolled ? "rgba(8,8,8,0.88)" : "transparent",
        backdropFilter: scrolled ? "blur(20px)" : "none",
        WebkitBackdropFilter: scrolled ? "blur(20px)" : "none",
        transition: "border-color 0.3s, background 0.3s",
      }}
    >
      {/* Logo */}
      <Link
        href="/"
        aria-label="Octopilot home"
        style={{
          fontFamily:    "var(--font-mono)",
          fontSize:      "13px",
          fontWeight:    700,
          letterSpacing: "0.12em",
          color:         "var(--text)",
        }}
      >
        OCTOPILOT
      </Link>

      {/* Nav links — hidden on mobile, shown md+ */}
      <ul
        aria-label="Navigation links"
        style={{
          display:    "flex",
          alignItems: "center",
          gap:        "2px",
          listStyle:  "none",
        }}
        className="hidden md:flex"
      >
        {links.map((link) => (
          <li key={link.href}>
            <Link
              href={link.href}
              style={{
                fontFamily:    "var(--font-mono)",
                fontSize:      "10.5px",
                letterSpacing: "0.08em",
                textTransform: "uppercase",
                color:         "var(--text-dim)",
                padding:       "6px 14px",
                borderRadius:  "4px",
                transition:    "color 0.15s, background 0.15s",
                display:       "block",
              }}
              onMouseEnter={(e) => {
                (e.target as HTMLElement).style.color = "var(--text)";
                (e.target as HTMLElement).style.background = "rgba(255,255,255,0.05)";
              }}
              onMouseLeave={(e) => {
                (e.target as HTMLElement).style.color = "var(--text-dim)";
                (e.target as HTMLElement).style.background = "transparent";
              }}
            >
              {link.label}
            </Link>
          </li>
        ))}
      </ul>

      {/* Right CTA */}
      <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
        <Link
          href="/login"
          className="btn-ghost hidden sm:inline-flex"
          style={{ height: "var(--btn-height-sm)", padding: "0 16px", fontSize: "9px" }}
        >
          Log in
        </Link>
        <Link href="#early-access" className="btn btn-accent">
          Get Early Access
        </Link>
      </div>
    </nav>
  );
}

// ── Main Component ────────────────────────────────────────────
export function HeroSection({ className }: HeroSectionProps) {
  return (
    <>
      <SiteNav />

      <section
        className={cn("hero-section", className)}
        aria-label="Hero"
        style={{
          minHeight:     "100svh",
          display:       "flex",
          flexDirection: "column",
          position:      "relative",
          overflow:      "hidden",
          borderBottom:  "1px solid var(--border)",
          paddingTop:    "var(--nav-height)",
        }}
      >
        {/* ── Background layers (z-0) ── */}

        {/* Starfield canvas */}
        <StarfieldCanvas />

        {/* Radial accent glow */}
        <div
          aria-hidden="true"
          style={{
            position: "absolute",
            inset: 0,
            zIndex: 0,
            pointerEvents: "none",
            background: `
              radial-gradient(ellipse 85% 55% at 50% -5%, rgba(255,99,8,0.09) 0%, transparent 65%),
              radial-gradient(ellipse 40% 40% at 80% 80%, rgba(100,130,210,0.04) 0%, transparent 60%)
            `,
          }}
        />

        {/* Grid overlay */}
        <div
          aria-hidden="true"
          className="grid-overlay"
          style={{ position: "absolute", inset: 0, zIndex: 0, pointerEvents: "none" }}
        />

        {/* ── Content (z-2) ── */}
        <div
          style={{
            flex:          1,
            display:       "flex",
            flexDirection: "column",
            justifyContent: "flex-end",
            padding:       "60px 40px 0",
            position:      "relative",
            zIndex:        2,
            maxWidth:      "var(--content-width)",
            width:         "100%",
          }}
        >
          {/* Eyebrow */}
          <div
            style={{
              display:       "flex",
              alignItems:    "center",
              gap:           "16px",
              marginBottom:  "28px",
              animationDelay: "0s",
            }}
            className="animate-fade-up"
          >
            <LiveBadge />
          </div>

          {/* Headline */}
          <h1
            className="animate-fade-up"
            style={{
              fontFamily:    "var(--font-serif)",
              fontSize:      "clamp(48px, 7.5vw, 108px)",
              lineHeight:    0.93,
              letterSpacing: "-0.025em",
              fontWeight:    400,
              color:         "var(--text)",
              maxWidth:      "880px",
              marginBottom:  "32px",
              animationDelay: "0.1s",
            }}
          >
            Kamu tidak butuh izin mereka<br />
            untuk membuktikan{" "}
            <em
              style={{
                fontStyle: "italic",
                color:     "rgba(240,240,238,0.38)",
              }}
            >
              masalah mereka.
            </em>
          </h1>

          {/* Subheadline */}
          <p
            className="animate-fade-up"
            style={{
              fontSize:      "17px",
              fontWeight:    300,
              color:         "var(--text-dim)",
              maxWidth:      "520px",
              lineHeight:    1.75,
              marginBottom:  "40px",
              animationDelay: "0.2s",
            }}
          >
            Octopilot mengubah ranking data menjadi{" "}
            <strong style={{ fontWeight: 500, color: "var(--text)" }}>
              visual proof yang tidak bisa dibantah
            </strong>{" "}
            — dalam hitungan detik, tanpa meminta akses GA4 atau GSC dari siapapun.
          </p>

          {/* CTA Group */}
          <div
            className="animate-fade-up"
            style={{
              display:       "flex",
              alignItems:    "center",
              gap:           "12px",
              flexWrap:      "wrap",
              marginBottom:  "48px",
              animationDelay: "0.3s",
            }}
          >
            <Link
              href="#early-access"
              className="btn btn-accent btn-lg"
              aria-label="Join early access, free — no credit card required"
            >
              Start Free — No Credit Card
              <ArrowRight size={14} aria-hidden="true" />
            </Link>
            <Link
              href="#demo"
              className="btn btn-ghost btn-lg"
              aria-label="See how Octopilot works"
            >
              See a Live Proof →
            </Link>
          </div>

          {/* Trust signal row */}
          <div
            className="animate-fade-up"
            style={{
              display:       "flex",
              alignItems:    "center",
              gap:           "16px",
              marginBottom:  "40px",
              animationDelay: "0.38s",
            }}
          >
            <div
              style={{
                display:    "flex",
                alignItems: "center",
                gap:        "6px",
                color:      "var(--text-muted)",
                fontSize:   "12px",
                fontWeight: 300,
              }}
            >
              <Shield size={12} style={{ color: "var(--success)" }} aria-hidden="true" />
              14-day free trial
            </div>
            <div
              aria-hidden="true"
              style={{ width: 1, height: 14, background: "var(--border-strong)" }}
            />
            <div
              style={{
                display:    "flex",
                alignItems: "center",
                gap:        "6px",
                color:      "var(--text-muted)",
                fontSize:   "12px",
                fontWeight: 300,
              }}
            >
              <Zap size={12} style={{ color: "var(--accent)" }} aria-hidden="true" />
              Setup dalam 4 menit
            </div>
            <div
              aria-hidden="true"
              style={{ width: 1, height: 14, background: "var(--border-strong)" }}
            />
            <div
              style={{
                color:      "var(--text-muted)",
                fontSize:   "12px",
                fontWeight: 300,
              }}
            >
              Cancel kapan saja
            </div>
          </div>
        </div>

        {/* ── Hero Footer ── */}
        <div
          className="animate-fade-up"
          style={{
            padding:       "0 40px 32px",
            display:       "flex",
            alignItems:    "flex-end",
            justifyContent: "space-between",
            gap:           "32px",
            flexWrap:      "wrap",
            position:      "relative",
            zIndex:        3,
            animationDelay: "0.45s",
          }}
        >
          {/* Scroll cue */}
          <div
            aria-hidden="true"
            style={{ color: "var(--text-muted)", fontSize: "20px" }}
            className="animate-bounce-y"
          >
            ↓
          </div>

          {/* Social proof stats */}
          <SocialProofRow />

          {/* Announcement tag */}
          <div
            style={{
              display:       "flex",
              flexDirection: "column",
              alignItems:    "flex-end",
              gap:           "8px",
            }}
          >
            <span
              style={{
                fontFamily:    "var(--font-mono)",
                fontSize:      "8.5px",
                letterSpacing: "0.16em",
                textTransform: "uppercase",
                color:         "var(--accent)",
                border:        "1px solid var(--accent-border)",
                padding:       "3px 10px",
                borderRadius:  "100px",
              }}
              className="animate-pulse-badge"
            >
              New: AI Overview Impact Overlay
            </span>
            <p
              style={{
                fontSize:   "12.5px",
                fontWeight: 300,
                color:      "var(--text-dim)",
                textAlign:  "right",
                maxWidth:   "340px",
                lineHeight: 1.6,
              }}
            >
              Visualisasi bagaimana Google AI Overview menghancurkan visibility
              prospek — tanpa akses apapun dari mereka.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
