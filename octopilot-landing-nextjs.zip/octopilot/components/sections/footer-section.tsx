/**
 * FooterSection
 * ─────────────────────────────────────────────────────────────
 */

import Link from "next/link";
import { cn } from "@/lib/utils";

const links = {
  Product: [
    { label: "How it Works",   href: "#how"        },
    { label: "Features",       href: "#features"   },
    { label: "Pricing",        href: "#pricing"    },
    { label: "Comparison",     href: "#comparison" },
  ],
  Company: [
    { label: "About",          href: "/about"      },
    { label: "Blog",           href: "/blog"       },
    { label: "Changelog",      href: "/changelog"  },
    { label: "Contact",        href: "mailto:hello@octopilot.co" },
  ],
  Legal: [
    { label: "Privacy Policy", href: "/privacy"    },
    { label: "Terms of Use",   href: "/terms"      },
    { label: "Cookie Policy",  href: "/cookies"    },
  ],
};

const year = new Date().getFullYear();

interface FooterSectionProps {
  className?: string;
}

export function FooterSection({ className }: FooterSectionProps) {
  return (
    <footer
      aria-label="Site footer"
      className={cn("site-footer", className)}
      style={{
        padding:    "80px 40px 40px",
        borderTop:  "1px solid var(--border)",
        background: "var(--bg-card)",
      }}
    >
      <div style={{ maxWidth: "var(--content-width)", margin: "0 auto" }}>
        {/* Top row */}
        <div
          style={{
            display:             "grid",
            gridTemplateColumns: "2fr repeat(3, 1fr)",
            gap:                 "48px",
            marginBottom:        "64px",
          }}
          className="footer-grid"
        >
          {/* Brand */}
          <div>
            <Link
              href="/"
              aria-label="Octopilot home"
              style={{
                fontFamily:    "var(--font-mono)",
                fontSize:      "14px",
                fontWeight:    700,
                letterSpacing: "0.12em",
                color:         "var(--text)",
                display:       "block",
                marginBottom:  "16px",
              }}
            >
              OCTOPILOT
            </Link>
            <p
              style={{
                fontSize:   "13px",
                fontWeight: 300,
                color:      "var(--text-dim)",
                lineHeight: 1.7,
                maxWidth:   "280px",
                marginBottom: "20px",
              }}
            >
              AI-powered Sales Proof Intelligence. Kirim proof. Close client.
            </p>
            <a
              href="mailto:hello@octopilot.co"
              style={{
                fontFamily:    "var(--font-mono)",
                fontSize:      "10px",
                letterSpacing: "0.1em",
                color:         "var(--text-muted)",
                textTransform: "uppercase",
              }}
              aria-label="Email Octopilot team"
            >
              hello@octopilot.co
            </a>
          </div>

          {/* Link columns */}
          {Object.entries(links).map(([category, items]) => (
            <nav key={category} aria-label={`${category} links`}>
              <h3
                style={{
                  fontFamily:    "var(--font-mono)",
                  fontSize:      "9px",
                  textTransform: "uppercase",
                  letterSpacing: "0.2em",
                  color:         "var(--text-muted)",
                  marginBottom:  "20px",
                }}
              >
                {category}
              </h3>
              <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: "12px" }}>
                {items.map(({ label, href }) => (
                  <li key={label}>
                    <Link
                      href={href}
                      style={{
                        fontSize:   "13px",
                        fontWeight: 300,
                        color:      "var(--text-dim)",
                        transition: "color 0.15s",
                      }}
                      onMouseEnter={(e) => { (e.target as HTMLElement).style.color = "var(--text)"; }}
                      onMouseLeave={(e) => { (e.target as HTMLElement).style.color = "var(--text-dim)"; }}
                    >
                      {label}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>

        {/* Divider */}
        <div style={{ height: "1px", background: "var(--border)", marginBottom: "28px" }} aria-hidden="true" />

        {/* Bottom row */}
        <div
          style={{
            display:        "flex",
            alignItems:     "center",
            justifyContent: "space-between",
            flexWrap:       "wrap",
            gap:            "12px",
          }}
        >
          <p
            style={{
              fontFamily:    "var(--font-mono)",
              fontSize:      "10px",
              letterSpacing: "0.08em",
              color:         "var(--text-muted)",
            }}
          >
            © {year} Octopilot · octopilot.co
          </p>
          <p
            style={{
              fontFamily:    "var(--font-mono)",
              fontSize:      "9px",
              letterSpacing: "0.08em",
              color:         "var(--text-muted)",
              textTransform: "uppercase",
            }}
          >
            Send the proof. Close the client.
          </p>
        </div>
      </div>
    </footer>
  );
}
