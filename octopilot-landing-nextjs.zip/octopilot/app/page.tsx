import { HeroSection }       from "@/components/sections/hero-section";
import { ProblemSection }    from "@/components/sections/problem-section";
import { SolutionSection }   from "@/components/sections/solution-section";
import { FeaturesSection }   from "@/components/sections/features-section";
import { UseCaseSection }    from "@/components/sections/use-case-section";
import { ComparisonSection } from "@/components/sections/comparison-section";
import { PricingSection }    from "@/components/sections/pricing-section";
import { FAQSection }        from "@/components/sections/faq-section";
import { CTASection }        from "@/components/sections/cta-section";
import { FooterSection }     from "@/components/sections/footer-section";

export default function LandingPage() {
  return (
    <main id="main-content">
      <a href="#main-content" className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:p-4 focus:bg-accent focus:text-bg">
        Skip to main content
      </a>

      {/* 1. Hero — includes SiteNav */}
      <HeroSection />

      {/* 2. Problem */}
      <ProblemSection />

      {/* 3. Solution — How it works */}
      <SolutionSection />

      {/* 4. Feature Grid */}
      <FeaturesSection />

      {/* 5. Use Cases */}
      <UseCaseSection />

      {/* 6. Comparison */}
      <ComparisonSection />

      {/* 7. Pricing */}
      <PricingSection />

      {/* 8. FAQ */}
      <FAQSection />

      {/* 9. Final CTA + Early Access + Lifetime Deal */}
      <CTASection />

      {/* 10. Footer */}
      <FooterSection />
    </main>
  );
}
